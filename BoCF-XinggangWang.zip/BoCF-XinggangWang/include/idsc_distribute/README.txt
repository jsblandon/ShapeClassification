This fold contains a demo example for matching with the inner-distance shape context.
To run the demo, just type
	idsc_matching_demo
in Matlab command line, it will show the inner-distance and the matching result of two images.

For details, please refer to
	H. Ling and D.W. Jacobs. Shape Classification Using the Inner-Distance, IEEE Trans on Pattern Anal. and Mach. Intell. (PAMI), 29(2):286-299, 2007. 

Haibin Ling, hbling AT umiacs.umd.edu
Computer science department, University of Maryland, College Park
Apr, 19, 2007